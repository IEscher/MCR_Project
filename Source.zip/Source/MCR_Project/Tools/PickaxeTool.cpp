
#include "PickaxeTool.h"


int APickaxeTool::GetMiningLevel() const
{
	return MiningLevel;
}
